package com.uade.procesoyDesarrolloDeSoftware.TPPDSG9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tppdsg9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
