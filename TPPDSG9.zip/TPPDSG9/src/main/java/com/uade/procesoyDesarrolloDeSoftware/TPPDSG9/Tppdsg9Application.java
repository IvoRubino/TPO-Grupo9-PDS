package com.uade.procesoyDesarrolloDeSoftware.TPPDSG9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tppdsg9Application {

	public static void main(String[] args) {
		SpringApplication.run(Tppdsg9Application.class, args);
	}

}
